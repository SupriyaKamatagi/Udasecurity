package com.udacity.catpoint.service;

        import com.udacity.catpoint.image.service.ImageService;
        import com.udacity.catpoint.application.StatusListener;
        import com.udacity.catpoint.data.*;
        import static org.junit.jupiter.api.Assertions.*;
        import org.junit.jupiter.api.BeforeEach;
        import org.junit.jupiter.api.Test;
        import org.junit.jupiter.api.extension.ExtendWith;
       // import org.junit.jupiter.api.function.Executable;
        import org.junit.jupiter.params.ParameterizedTest;
      //  import org.junit.jupiter.params.provider.Arguments;
        import org.junit.jupiter.params.provider.EnumSource;
        import org.junit.jupiter.params.provider.ValueSource;
        import org.mockito.ArgumentCaptor;
        import org.mockito.Mock;
        import static org.mockito.Mockito.*;
        import org.mockito.junit.jupiter.MockitoExtension;

        import java.util.UUID;
        import java.awt.image.BufferedImage;
        import java.util.HashSet;
        import java.util.Set;
        //import java.util.stream.Stream;

@ExtendWith(MockitoExtension.class)
public class SecurityServiceTest {
    private final String randomString = UUID.randomUUID().toString();
    private Sensor sensor;
    private Set<Sensor> sensors;
    private StatusListener listener;
    @Mock
    SecurityRepository securityRepository;

    @Mock
    private ImageService imageService;

    private
    SecurityService securityService;


    private Sensor getSensors(){
        return new Sensor(randomString, SensorType.DOOR);
    }

    @BeforeEach
    void setUp() {
        securityService = new SecurityService(securityRepository, imageService);
        sensor = getSensors();
    }


    private Set<Sensor> getSensorTest(boolean active, int count){
        String randomString = UUID.randomUUID().toString();

        Set<Sensor> sensor = new HashSet<>();
        for (int i = 0; i <= count; i++){
            sensor.add(new Sensor(randomString, SensorType.DOOR));
        }
        sensor.forEach(it -> it.setActive(active));
        return sensor;
    }

    @Test//Covers Test case:01
    void changeAlrStatus_alarmArmedSensorActivatedAlrStatusPending(){
        when(securityService.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        when(securityService.getAlarmStatus()).thenReturn(AlarmStatus.NO_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        ArgumentCaptor<AlarmStatus> cap = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(cap.capture());
        assertEquals(cap.getValue(), AlarmStatus.PENDING_ALARM);
    }

    @ParameterizedTest//Covers Test case:02
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_HOME", "ARMED_AWAY"})
    void  changeAlarmStatusAlr_AlreadyPendingSensorActivatedSetAlrStatusAlarm(ArmingStatus armingStatus){
        when(securityService.getArmingStatus()).thenReturn(armingStatus);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, atMostOnce()).setAlarmStatus(AlarmStatus.ALARM);
    }

    @Test //Covers Test case:03
        void changeAlrStatusAlr_PendingAllSensorsInactiveSetAlrStatusToNoAlarm(){
            Set<Sensor> allSensors = getSensorTest(false, 4);
            Sensor first = allSensors.iterator().next();
            first.setActive(true);
            when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
            securityService.changeSensorActivationStatus(first, false);
            verify(securityRepository, times(1)).setAlarmStatus(AlarmStatus.NO_ALARM);
        }


    @ParameterizedTest//Covers Test case:04
    @ValueSource(booleans = {true,false})
    void updateAlrStatus_sensorStatusChangeSystemIsAlreadyDisArmedStateNotAffected(boolean armingState){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.ALARM);
        securityService.changeSensorActivationStatus(sensor, armingState);
        verify(securityRepository, never()).setAlarmStatus(any(AlarmStatus.class));
    }

    @Test //Covers Test case:05
    void updateAlarmState_systemAlreadyActiveAlarmPendingSetToAlarmState(){
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        securityService.changeSensorActivationStatus(sensor, true);
        verify(securityRepository, atMostOnce()).setAlarmStatus(AlarmStatus.ALARM);
    }

    @ParameterizedTest //Covers Test case:06
    @EnumSource(value = AlarmStatus.class, names = {"NO_ALARM", "PENDING_ALARM", "ALARM"})
    void updateAlrState_sensorDeactivateInactiveSetNoChangeToAlarmState(AlarmStatus alarmStatus){
        securityService.changeSensorActivationStatus(sensor, false);
        verify(securityRepository, never()).setAlarmStatus(any());
    }

    @Test //Covers Test case:07
    void updateAlrState_imageContainingCatDetectedSystemArmedSetToAlarmStatus(){
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        securityService.processImage(mock(BufferedImage.class));
        ArgumentCaptor<AlarmStatus> cap = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(cap.capture());
        assertEquals(cap.getValue(), AlarmStatus.ALARM);
    }

    @Test //Covers Test case:08
    void updateAlrState_noCatImageIdentifiedSensorsAreInactiveChangeToAlrStatus(){
        Set<Sensor> inactiveSensors = getSensorTest(false, 2);
        when(securityRepository.getSensors()).thenReturn(inactiveSensors);
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(false);
        securityService.processImage(mock(BufferedImage.class));
        verify(securityRepository, atMostOnce()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }

    @Test //Covers Test case:09
    void updateAlarmStatus_systemDisArmChangeToAlrStatus(){
        securityService.setArmingStatus(ArmingStatus.DISARMED);
        verify(securityRepository, atMostOnce()).setAlarmStatus(AlarmStatus.NO_ALARM);
    }


    @ParameterizedTest //Covers Test case:10
    @EnumSource(value = ArmingStatus.class, names = {"ARMED_AWAY", "ARMED_HOME"})
    void changeSensors_systemArmedSetDeactivateAllSensors(ArmingStatus armingStatus){
        Set<Sensor> sensors = getSensorTest(true, 3);
        when(securityRepository.getAlarmStatus()).thenReturn(AlarmStatus.PENDING_ALARM);
        when(securityRepository.getSensors()).thenReturn(sensors);
        securityService.setArmingStatus(armingStatus);
        securityRepository.getSensors().forEach(sensor -> assertFalse(sensor.getActive()));
    }

    @Test//Covers Test case:11
    void changeAlrStatus_systemArmedHomeCatDetectedChangeToAlrStatus(){
        when(imageService.imageContainsCat(any(), anyFloat())).thenReturn(true);
        when(securityRepository.getArmingStatus()).thenReturn(ArmingStatus.ARMED_HOME);
        securityService.processImage(mock(BufferedImage.class));
        ArgumentCaptor<AlarmStatus> captor = ArgumentCaptor.forClass(AlarmStatus.class);
        verify(securityRepository, atMostOnce()).setAlarmStatus(captor.capture());
        assertEquals(captor.getValue(), AlarmStatus.ALARM);
    }



}